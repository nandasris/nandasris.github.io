package com.example.rumah_sakit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
